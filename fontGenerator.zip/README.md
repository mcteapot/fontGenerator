# fontGenerator

## History

script to help artist create fonts with Adobe illustrator and FontLab Studio 

## Credits

The people that made this:

[Arjun Prakash](http://www.cyborgdino.com/):  Programming

Also Thanks to: 

[Joaquim Nielsen](http://www.youtube.com/user/JoKKeSvin?feature=watch) for a sweet tutorial and illustrator file to export fonts into FontLab.
[http://youtu.be/fOTLwmmrv8s](http://youtu.be/fOTLwmmrv8s)


## License

GPL (General Public License). You can distribute modified versions of the source code, but they must also be open source under the GPL. The game assets (graphics, music, etc.) can be redistributed for free, but cannot be resold without our permission.